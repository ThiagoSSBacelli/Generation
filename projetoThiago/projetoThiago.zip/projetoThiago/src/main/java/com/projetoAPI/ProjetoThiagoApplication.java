package com.projetoAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoThiagoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoThiagoApplication.class, args);
	}

}
