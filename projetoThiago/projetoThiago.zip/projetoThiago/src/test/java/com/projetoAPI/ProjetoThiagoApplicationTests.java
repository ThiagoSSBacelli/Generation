package com.projetoAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoThiagoApplicationTests {

	@Test
	void contextLoads() {
	}

}
